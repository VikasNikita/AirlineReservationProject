package com.example.demo;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.modal.Admin;
import com.example.demo.modal.Flight;
import com.example.demo.repo.AdminRepositoryImple;
import com.example.demo.repo.FlightRepositoryImple;

@SpringBootTest
public class FlightTestCases 
{
	@Autowired
	FlightRepositoryImple flightRepo;
	
	@Autowired
	AdminRepositoryImple adminRepo;
	
//	@Test
//	void loginAdmin() {
//		System.out.println("Admin Login");
//		Admin admin = new Admin("nikita31@gmail.com", "1234556");
//		adminRepo.loginAdmin(admin);
//		System.out.println("Admin Login Repository Testing Successful");
//		
//	}
	
	
	
	
	@Test
	void insertAdminTest()
	{
		System.out.println("Adding Admin");
//		Admin admin=new Admin();
//		admin.setAdminId(41);
//		admin.setAdminEmailId("nikita31@gmail.com");
//		admin.setAdminPassward("1234556");
//		adminRepo.insertAdmin(admin);
		System.out.println("Insert Admin successfully");
		
		Admin admin1=new Admin();
		admin1.setAdminId(42);
		admin1.setAdminEmailId("nikita31@gmail.com");
		admin1.setAdminPassward("1234556");
		adminRepo.insertAdmin(admin1);
		System.out.println("Insert Admin Succesfully");
		
	}
	@Test
	void addFlightTest() {
		
		System.out.println("Adding Flight");
		LocalDateTime dateTime=LocalDateTime.of(2021,12,12,2,13,40);
		LocalDateTime dateTime2=LocalDateTime.of(2021,12,21,4,23,34);
		Flight f1 = new Flight(27,"AirlineIndia","Mumbai","Pune",dateTime, dateTime2,1200,1300,20,20,10,10);
		adminRepo.addFlight(f1);

		LocalDateTime dateTime3=LocalDateTime.of(2021,11,14,7,12,59);
		LocalDateTime dateTime4=LocalDateTime.of(2021,4,22,9,28,58);
		Flight f2 = new Flight(28,"AirlinePune","Aurangabad","Pune",dateTime3, dateTime4,1200,1300,20,20,10,10);
		adminRepo.addFlight(f2);
		
		System.out.println("Admin Flight Repository Add-Testing Successful");
	}
	
	@Test
	void updateFlightTest()
	{
		LocalDateTime dateTime=LocalDateTime.of(2021,12,12,2,13,40);
		LocalDateTime dateTime2=LocalDateTime.of(2021,12,21,4,23,34);
		Flight f1 = new Flight(21,"AirlinePune","Goa","Pune",dateTime, dateTime2,1200,1300,20,20,10,10);
		adminRepo.updateFlight(f1);
		System.out.println("Flight Updated Succesfully...................");
	}
	
	@Test
	void deleteFlightTest()
	{
		 adminRepo.deleteFlight(27);
		System.out.println("Delete file succesfully");
	}
	
	@Test
	void getselectFlightTest()
	{
		Flight flight;
		flight=flightRepo.selectFlights(21);
		System.out.println("flight id: "                   +flight.getFlightId());
		System.out.println("flight name : "                +flight.getFlightName());
		System.out.println("flight source location :"      +flight.getSourceLoc());
		System.out.println("flight destination location:"  +flight.getDestinationLoc());
		System.out.println("flight departure date time :"  +flight.getDepartureDateTime());
		System.out.println("flight arrival date time :"    +flight.getArrivalDateTime());
		System.out.println("flight economy seat price :"   +flight.getEconomySeatPrice());
		System.out.println("Flight business seat price: "  +flight.getBusinessSeatPrice());
		System.out.println("Flight business total seats :" +flight.getTotalbusinessSeats());
		System.out.println("Flight economy total seats :"  +flight.getTotalEconomySeats());
		System.out.println("Flight Available Business seats:"+flight.getAvailableBusinessSeats());
		System.out.println("Flight Available economy Seats:"+flight.getAvailableEconomySeats());
		System.out.println("Flight Select Succesfully");
	}
	
	@Test
	void selectAllFlightsTest()
	{
		List<Flight> flightList;
		flightList=flightRepo.FetchAllFlight();
		for (Flight flight : flightList)
		{
			System.out.println("flight id: "                   +flight.getFlightId());
			System.out.println("flight name : "                +flight.getFlightName());
			System.out.println("flight source location :"      +flight.getSourceLoc());
			System.out.println("flight destination location:"  +flight.getDestinationLoc());
			System.out.println("flight departure date time :"  +flight.getDepartureDateTime());
			System.out.println("flight arrival date time :"    +flight.getArrivalDateTime());
			System.out.println("flight economy seat price :"   +flight.getEconomySeatPrice());
			System.out.println("Flight business seat price: "  +flight.getBusinessSeatPrice());
			System.out.println("Flight business total seats :" +flight.getTotalbusinessSeats());
			System.out.println("Flight economy total seats :"  +flight.getTotalEconomySeats());
			System.out.println("Flight Available Business seats:"+flight.getAvailableBusinessSeats());
			System.out.println("Flight Available economy Seats:"+flight.getAvailableEconomySeats());
			System.out.println("All Flights Selected Succesfully");
		}
	}
}
