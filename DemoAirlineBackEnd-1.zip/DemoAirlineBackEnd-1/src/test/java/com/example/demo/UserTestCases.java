package com.example.demo;

import java.time.LocalDate;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.modal.PassengerTable;
import com.example.demo.modal.Seat;
import com.example.demo.modal.User;
import com.example.demo.repo.PassengerRepositoryImple;
import com.example.demo.repo.UserRepositoryImple;

@SpringBootTest
public class UserTestCases 
{
	@Autowired
	UserRepositoryImple userRepo;
	
	@Autowired
	PassengerRepositoryImple passengerRepo;
	
	
	
	
	@Test
	void userInsert()
	{
			User user=new User();
		
			user.setUserId(81);
			user.setFirstName("Nikita");
			user.setLastName("BHavsar");
			user.setEmailId("nikita@123gmail.com");
			user.setPassward("123");
			user.setDob(LocalDate.of(1997,7, 31));
			user.setMobNumber(345678);
			userRepo.insertUser(user);

			User user2=new User();
			user2.setUserId(82);
			user2.setFirstName("Nikita");
			user2.setLastName("BHavsar");
			user2.setEmailId("nikita@123gmail.com");
			user2.setPassward("123");
			user2.setDob(LocalDate.of(1997,7, 31));
			user2.setMobNumber(345678);
			userRepo.insertUser(user2);
	}
	
	@Test
	void insertPassengerTable()
	{
		User user=userRepo.selectUser(83);
		
		LocalDate localDate=LocalDate.of(1997, 12, 12);
		
		PassengerTable passengerTable=new PassengerTable();
		passengerTable.setPassengerId(71);
		passengerTable.setFirstName("Nikita");
		passengerTable.setGender("female");
		passengerTable.setDateOfBirth(localDate);
		passengerTable.setUser(user);
		passengerRepo.insertPassengerTable(passengerTable);
		
		
		PassengerTable passengerTable1=new PassengerTable();
		passengerTable1.setPassengerId(72);
		passengerTable1.setFirstName("Ranu");
		passengerTable1.setGender("female");
		passengerTable1.setDateOfBirth(localDate);
		passengerTable1.setUser(user);
		passengerRepo.insertPassengerTable(passengerTable1);
		
	}
	
//	@Test
//	void insertseat()
//	{
//		Seat seat=new Seat();
//		seat.setSeatNumber(71);
//		seat.setSeatType("Economic");
//		seatRepo.save(seat);
//	}
	
}
