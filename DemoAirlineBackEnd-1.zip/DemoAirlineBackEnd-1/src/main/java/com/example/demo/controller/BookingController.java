package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.modal.Bookings;
import com.example.demo.repo.BookingRepoImple;

@RestController
@RequestMapping("/booking")
public class BookingController
{
	
	@Autowired
	BookingRepoImple bookingRepo;
	
	@GetMapping("/get/{bid}")
	public Bookings getFlight(@PathVariable("bid") int bid)
	{
		Bookings bookings;
		bookings=bookingRepo.selectBooking(bid);
		return bookings;
	}
	//http://localhost:8080/dept/getAll
	//http://localhost:8080/dept/getAll
	
	@GetMapping("/getAll")
	public List<Bookings> getBookings()
	{
		List<Bookings> bookingList;
		bookingList=bookingRepo.selectBooking();
		return bookingList;
	}
	
	
	@PostMapping("/Add")
	public void addBookings(@RequestBody Bookings bookings)
	{
		bookingRepo.insertBooking(bookings);
	}
	
	
	@PutMapping("/update")
	public void updateBooking(@RequestBody Bookings bookings)
	{
		bookingRepo.updateBookings(bookings);
	}
	
//	@DeleteMapping("/delete/{bid}")
//	public String deleteDept(@PathVariable("fid") int fid)
//	{
//		flightRepo.deleteFlight(fid);
//		return "delete successfully";
//	}
}	
	
