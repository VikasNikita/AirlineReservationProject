package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.modal.User;
import com.example.demo.repo.UserRepositoryImple;

@RestController
@RequestMapping("/user")
public class UserController
{
	
	@Autowired
	UserRepositoryImple userRepo;
	
	@GetMapping("/get/{uid}")
	public User getUser(@PathVariable("uid" ) int id)
	{
		User user;
		user=userRepo.selectUser(id);
		return user;
	}
	
	@GetMapping("/getAll")
	public List<User> getUsers()
	{
		List<User> userlist;
		userlist=userRepo.selectUsers();
		return userlist;
	}
	
	@PostMapping("/add")
	public void addUser (@RequestBody User user)
	{
		userRepo.insertUser(user);
	}
	
	@PutMapping("/update")
	public void updateUser(@RequestBody User user)
	{
		userRepo.updateUser(user);
	}
	
	@DeleteMapping("/delete/{uid}")
	public String deleteFlight(@PathVariable ("uid") int uid) 
	{
		userRepo.deleteUser(uid);
		return "delete successfully";
	}
	
}
