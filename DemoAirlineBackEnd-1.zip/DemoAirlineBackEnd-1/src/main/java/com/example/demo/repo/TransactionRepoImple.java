package com.example.demo.repo;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.TransactionTable;

@Repository
public class TransactionRepoImple extends BaseRepository implements TransactionRepo
{
	

	public TransactionRepoImple() {
		super();
		System.out.println("TransactionImple.................");
	}

	@Transactional
	public void insertTransaction(TransactionTable tobj) {
		super.persist(tobj);
	}

	@Override
	public TransactionTable selectTransaction(int tid) {
		TransactionTable transaction=super.find(TransactionTable.class, tid);
	
		return transaction;
	}

	@Override
	public List<TransactionTable> selectTransactions() {
		List<TransactionTable> list=new ArrayList<TransactionTable>();
		return super.findAll("TransactionTable");
	}

	@Transactional
	public void updateTransaction(TransactionTable dobj) {
		super.merge(dobj);
	}

	@Override
	public void deleteTransaction(int tid) {
		super.remove(TransactionTable.class, tid);
	}

}
