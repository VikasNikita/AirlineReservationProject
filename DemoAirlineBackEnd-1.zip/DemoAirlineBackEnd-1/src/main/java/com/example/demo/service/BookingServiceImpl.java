package com.example.demo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.modal.Bookings;
import com.example.demo.modal.Flight;
import com.example.demo.repo.BookingRepoImple;

public class BookingServiceImpl implements BookingService
{
	@Autowired
	BookingRepoImple bookingRepo;
	
	@Override
	public List<Bookings> getBookingDetails() {
		// TODO Auto-generated method stub
		return bookingRepo.selectBooking();
	}

	@Override
	public void insertFlight(Bookings bookings) {
		bookingRepo.persist(bookings);
		
	}

	@Override
	public void updateBookingDetails(int id, Bookings bookings) {
		bookings.setBookingId(id);
		bookingRepo.persist(bookings);
		
	}

	@Transactional
	public void deleteBookingsDetails(int id) {
		bookingRepo.deleteBookings(id);
		
	}
	
}
