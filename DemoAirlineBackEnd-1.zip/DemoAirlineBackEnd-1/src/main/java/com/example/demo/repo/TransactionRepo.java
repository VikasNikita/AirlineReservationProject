package com.example.demo.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.TransactionTable;


@Repository
public interface TransactionRepo {
	void insertTransaction(TransactionTable tobj); //C
	
	TransactionTable selectTransaction(int tid); //R
	List<TransactionTable> selectTransactions(); //RA
	
	void updateTransaction(TransactionTable dobj); //U
	void deleteTransaction(int tid); //D
	
}
