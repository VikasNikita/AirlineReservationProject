package com.example.demo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.modal.User;
import com.example.demo.repo.UserRepositoryImple;

public class UserServiceImpl implements UserService
{
	@Autowired
	UserRepositoryImple userRepo; 
	
	@Override
	public List<User> getUserDetails() {
		// TODO Auto-generated method stub
		return userRepo.selectUsers();
	}

	@Override
	public void insertUser(User user) {
		// TODO Auto-generated method stub
		userRepo.persist(user);
	}

	@Override
	public void updateUserDetails(int id, User user) {
		// TODO Auto-generated method stub
		user.setUserId(id);
		userRepo.persist(user);
	}

	@Transactional
	public void deleteUserDetails(int id) {
		// TODO Auto-generated method stub
		userRepo.deleteUser(id);
	}
		
}
