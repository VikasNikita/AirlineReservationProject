package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.modal.Flight;
import com.example.demo.repo.FlightRepositoryImple;


@Service
public class FlightServiceImple implements FlightService
{
	@Autowired
	FlightRepositoryImple flightrepo;

	@Override
	public List<Flight> getFlightDetails() 
	{
		
		return flightrepo.FetchAllFlight();
	}

	@Override
	public void insertFlight(Flight flight) {
		flightrepo.persist(flight);
	}

	@Override
	public void updateFlightDetails(int id, Flight flight) {
		flight.setFlightId(id);
		flightrepo.persist(flight);
		
	}

	@Transactional
	public void deleteFlightDetails(int id) {
		flightrepo.deleteFlight(id);
	}

	
	
	
}
