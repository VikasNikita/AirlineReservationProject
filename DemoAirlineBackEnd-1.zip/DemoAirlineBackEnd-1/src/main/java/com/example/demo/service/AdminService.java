package com.example.demo.service;
/*
import java.util.List;
import com.example.demo.modal.Admin;

public interface AdminService {
	public List<Admin> getAdminDetails();
	public void insertAdmin(Admin admin);
	public void updateAdminDetails(int id,Admin admin);
	public void deleteAdminDetails(int id);
}
*/
