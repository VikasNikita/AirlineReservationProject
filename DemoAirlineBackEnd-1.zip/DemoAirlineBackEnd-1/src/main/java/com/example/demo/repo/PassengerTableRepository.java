package com.example.demo.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.PassengerTable;


@Repository
public interface PassengerTableRepository
{
	void insertPassengerTable(PassengerTable pobj); 
	PassengerTable selectPassenger(int pid); 
	List<PassengerTable> selectPassengerTable(); 
	void updatePassengerTable(PassengerTable pobj); 
	void deletePassengerTable(int pid); 
}
