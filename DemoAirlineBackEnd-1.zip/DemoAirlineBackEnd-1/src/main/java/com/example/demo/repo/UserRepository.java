package com.example.demo.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.Admin;
import com.example.demo.modal.User;

@Repository
public interface UserRepository 
{
	void insertUser(User uobj); //C
	User selectUser(int uid); //R
	List<User> selectUsers(); //RA
	void updateUser(User uobj); //U
	void deleteUser(int uid);

}
