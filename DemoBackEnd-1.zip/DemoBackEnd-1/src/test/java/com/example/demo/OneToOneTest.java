package com.example.demo;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.modal.Cancellation;
import com.example.demo.modal.Transaction;
import com.example.demo.repo.CancellationRepoImpl;
import com.example.demo.repo.TransactionRepoImple;

@SpringBootTest
public class OneToOneTest
{
	@Autowired
	TransactionRepoImple tranrepo;
	
	@Autowired
	CancellationRepoImpl canrepo;
	
	@Test
	void insertTranTest()
	{
		Transaction tran=new Transaction();
		tran.setTrannsactionId(1);
		tran.setTransactionType("Online");
		tran.setTransactionAmount(12000.0f);
		tran.setTransactionMode("succ");
		tran.setTransactionStatus("active");
		tranrepo.insertTransaction(tran);
	}
	
	@Test
	void insertCanTest()
	{
		LocalDate localDate=LocalDate.of(2020, 12, 12);
		
		Cancellation can=new Cancellation();
		can.setCancellationId(11);
		can.setCancellationReason("Some issue");
		can.setCancellationStatus("succ");
		can.setRefundAmount(12000.0f);
		can.setCancellationDate(localDate);
		
		canrepo.insertCancellation(can);
		
		
	}
	@Test
	void assignExistingTransactionToExistingCancellation()
	{
		Transaction transaction=tranrepo.find(Transaction.class,1 );
		Cancellation cancellation=canrepo.find(Cancellation.class, 11);
		
		transaction.setCancellation(cancellation);
		cancellation.setTransaction(transaction);
		
		tranrepo.merge(cancellation);
		canrepo.merge(transaction);
	}
	
	
}
