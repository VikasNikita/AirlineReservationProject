package com.example.demo;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.modal.Cancellation;
import com.example.demo.modal.Transaction;
import com.example.demo.repo.CancellationRepoImpl;
import com.example.demo.repo.TransactionRepoImple;

@SpringBootTest
public class OneToOneTest
{
	@Autowired
	TransactionRepoImple tranrepo;
	
	@Autowired
	CancellationRepoImpl canrepo;
	
	@Test
	void insertTranTest()
	{
		Transaction tran=new Transaction();
		tran.setTrannsactionId(1);
		tran.setTransactionType("Online");
		tran.setTransactionAmount(12000.0f);
		tran.setTransactionMode("succ");
		tran.setTransactionStatus("active");
		tranrepo.insertTransaction(tran);
		
		
		
		
		Transaction tran1=new Transaction();
		tran1.setTrannsactionId(2);
		tran1.setTransactionType("Online");
		tran1.setTransactionAmount(12000.0f);
		tran1.setTransactionMode("succ");
		tran1.setTransactionStatus("active");
		tranrepo.insertTransaction(tran1);
	}
	
	
	@Test
	void selectTranTest()
	{
		Transaction transaction;
		transaction=tranrepo.selectTransaction(1);

		System.out.println("Transaction id: "+transaction.getTrannsactionId());
		System.out.println("Transaction Type :"+transaction.getTransactionType());
		System.out.println("Transaction Amount: "+transaction.getTransactionMode());
		System.out.println("Transaction Status:"+transaction.getTransactionStatus());
		
	
	}
	@Test
	void selectAllTransTest()
	{
		List<Transaction> tranList;
		tranList=tranrepo.selectTransactions();
		for(Transaction transaction : tranList)
		{
			System.out.println("Transaction id: "+transaction.getTrannsactionId());
			System.out.println("Transaction Type :"+transaction.getTransactionType());
			System.out.println("Transaction Amount: "+transaction.getTransactionMode());
			System.out.println("Transaction Status:"+transaction.getTransactionStatus());
		}
	}
	
	@Test
	void insertCanTest()
	{
		LocalDate localDate=LocalDate.of(2020, 12, 12);
		
		Cancellation can=new Cancellation();
		can.setCancellationId(11);
		can.setCancellationReason("Some issue");
		can.setCancellationStatus("succ");
		can.setRefundAmount(12000.0f);
		can.setCancellationDate(localDate);
	
		Cancellation cancellation=new Cancellation();
		cancellation.setCancellationId(12);
		cancellation.setCancellationReason("Some issue");
		cancellation.setCancellationStatus("succ");
		cancellation.setRefundAmount(12000.0f);
		cancellation.setCancellationDate(localDate);
		
		canrepo.insertCancellation(can);
		canrepo.insertCancellation(cancellation);
		
		
	}
	@Test
	void assignExistingTransactionToExistingCancellation()
	{
		Transaction transaction=tranrepo.find(Transaction.class,1 );
		Cancellation cancellation=canrepo.find(Cancellation.class, 11);
		
		transaction.setCancellation(cancellation);
		cancellation.setTransaction(transaction);
		
		tranrepo.merge(cancellation);
		canrepo.merge(transaction);
	}
	
	@Test
	void selectCanTest()
	{
		Cancellation can;
		can=canrepo.selectCancellation(11);

		System.out.println("Cancellation id: "+can.getCancellationId());
		System.out.println("Cancellation date:"+can.getCancellationDate());
		System.out.println("Cancellation reason: "+can.getCancellationReason());
		System.out.println("Cancellation status: "+can.getCancellationStatus());
		System.out.println("Cancellation Refund:"+can.getRefundAmount());
	
	}
	
	@Test
	void selectAllCanTest()
	{
		List<Cancellation> canList;
		canList=canrepo.selectCancellation();
		for(Cancellation can : canList)
		{
			System.out.println("Cancellation id: "+can.getCancellationId());
			System.out.println("Cancellation date:"+can.getCancellationDate());
			System.out.println("Cancellation reason: "+can.getCancellationReason());
			System.out.println("Cancellation status: "+can.getCancellationStatus());
			System.out.println("Cancellation Refund:"+can.getRefundAmount());
		}
	
	}
}
