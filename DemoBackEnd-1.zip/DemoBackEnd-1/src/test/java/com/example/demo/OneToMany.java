package com.example.demo;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.modal.Bookings;
import com.example.demo.modal.Flight;
import com.example.demo.repo.BookingRepoImple;
import com.example.demo.repo.FlightRepositoryImple;

@SpringBootTest
public class OneToMany
{
	@Autowired
	FlightRepositoryImple flightRepo;
	
	@Autowired
	BookingRepoImple bookingRepo;
	
	@Test
	void addFlightTest() {
		
		System.out.println("Adding Flight");
		LocalDateTime dateTime=LocalDateTime.of(2021,12,12,2,13,40);
		LocalDateTime dateTime2=LocalDateTime.of(2021,12,21,4,23,34);
		Flight f1 = new Flight(21,"AirlineIndia","Mumbai","Pune",dateTime, dateTime2,1200,1300,20,20,10,10);
		flightRepo.insertFlight(f1);
		System.out.println("Admin Flight Repository Add-Testing Successful");
	}
	
	@Test
	void createBookingtest() {
		Flight flight = flightRepo.selectFlight(21);
		
		
		Bookings bookings = new Bookings();
		LocalDate date = LocalDate.now();
//		booking.setBookingDate(date);
//		booking.setTravelStartDate(date);
//		booking.setFlight(flight);
//		booking.setClassType("Economy");
//		booking.setJourneyType("One_Way");
//		booking.setNoOfSeatsBookedByUser(2);
//		booking.setFlightCustomer(user);
//		booking.setBookingStatus("Payment_Failed");
		bookings.setBookingId(31);
		bookings.setBusinessSeatsBooked(12);
		bookings.setEconomySeatsBooked(12);
		bookings.setBookingDate(date);
		bookings.setJourneyType("Within Country");
		bookings.setTotalCost(3000);
		bookings.setFlight(flight);
		bookingRepo.insertBooking(bookings);
		
	}

	
	
}
