package com.example.demo.repo;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.example.demo.modal.Bookings;

@Repository
public interface BookingRepository
{
	void insertBooking(Bookings bobj); //C
	
	Bookings selectBooking(int bid); //R
	List<Bookings> selectCancellation(); //RA
	
	void updateBookings(Bookings bobj); //U
	void deleteBookings(int bid);
}
