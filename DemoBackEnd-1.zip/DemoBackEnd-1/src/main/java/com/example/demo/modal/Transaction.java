package com.example.demo.modal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="transaction")
public class Transaction {

	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="tranid")
	private int trannsactionId;
	
	@Column(name="trantype")
	private String transactionType;
	
	@Column(name="tranmode")
	private String transactionMode;
	
	@Column(name="tranamount")
	private float transactionAmount;
	
	@Column(name="transtatus")
	private String transactionStatus;


	@OneToOne(cascade = CascadeType.ALL,mappedBy = "transaction")
	private Cancellation cancellation;
	
	
	@OneToOne(cascade = CascadeType.ALL,mappedBy = "transaction")
	private Bookings bookings;
	

	public Cancellation getCancellationTable() {
		return cancellation;
	}

	public void setCancellation(Cancellation cancellation) {
		this.cancellation = cancellation;
	}

	public Bookings getBookings() {
		return bookings;
	}

	public void setBookings(Bookings bookings) {
		this.bookings = bookings;
	}

	public int getTrannsactionId() {
		return trannsactionId;
	}

	public void setTrannsactionId(int trannsactionId) {
		this.trannsactionId = trannsactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getTransactionMode() {
		return transactionMode;
	}

	public void setTransactionMode(String transactionMode) {
		this.transactionMode = transactionMode;
	}

	public float getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(float transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	@Override
	public String toString() {
		return "Transaction [trannsactionId=" + trannsactionId + ", transactionType=" + transactionType
				+ ", transactionMode=" + transactionMode + ", transactionAmount=" + transactionAmount
				+ ", transactionStatus=" + transactionStatus + ", cancellation=" + cancellation + "]";
	}

}