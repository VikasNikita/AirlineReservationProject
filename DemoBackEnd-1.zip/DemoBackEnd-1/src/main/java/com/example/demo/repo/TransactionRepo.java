package com.example.demo.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.Transaction;


@Repository
public interface TransactionRepo {
	void insertTransaction(Transaction tobj); //C
	
	Transaction selectTransaction(int tid); //R
	List<Transaction> selectTransactions(); //RA
	
	void updateTransaction(Transaction dobj); //U
	void deleteTransaction(int tid); //D
	
}
