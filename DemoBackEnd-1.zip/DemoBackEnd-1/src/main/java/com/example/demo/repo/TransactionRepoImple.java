package com.example.demo.repo;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.Transaction;

@Repository
public class TransactionRepoImple extends BaseRepository implements TransactionRepo
{
	

	public TransactionRepoImple() {
		super();
		System.out.println("TransactionImple.................");
	}

	@Transactional
	public void insertTransaction(Transaction tobj) {
		super.persist(tobj);
	}

	@Override
	public Transaction selectTransaction(int tid) {
		Transaction transaction=super.find(Transaction.class, tid);
	
		return transaction;
	}

	@Override
	public List<Transaction> selectTransactions() {
		List<Transaction> list=new ArrayList<Transaction>();
		return super.findAll("Transaction");
	}

	@Override
	public void updateTransaction(Transaction dobj) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteTransaction(int tid) {
		// TODO Auto-generated method stub
		
	}

}
