package com.example.demo.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.Transaction;

@Repository
public class TransactionRepoImple extends BaseRepository implements TransactionRepo
{
	

	public TransactionRepoImple() {
		super();
		System.out.println("TransactionImple.................");
	}

	@Transactional
	public void insertTransaction(Transaction tobj) {
		super.persist(tobj);
	}

	@Override
	public Transaction selectTransaction(int tid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> selectTransactions() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateTransaction(Transaction dobj) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteTransaction(int tid) {
		// TODO Auto-generated method stub
		
	}

}
