package com.example.demo.modal;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity  
@Table(name="cancellation1")
public class Cancellation
{
	@Id
//	@GeneratedValue
	@Column(name="canid")
	private int cancellationId;
	
	@Column(name="candate")
	private LocalDate cancellationDate;
	
	@Column(name="canreason")
	private String cancellationReason;
	
	@Column(name="canstatus")
	private String cancellationStatus;
	
	@Column(name="refamount")
	private double refundAmount;
	
	@OneToOne
	private Transaction transaction;
	
	
	
	public Cancellation() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Cancellation(int cancellationId, LocalDate cancellationDate, String cancellationReason,
			String cancellationStatus, double refundAmount, Transaction transaction) {
		super();
		this.cancellationId = cancellationId;
		this.cancellationDate = cancellationDate;
		this.cancellationReason = cancellationReason;
		this.cancellationStatus = cancellationStatus;
		this.refundAmount = refundAmount;
		this.transaction = transaction;
	}


	public Transaction getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}

	public int getCancellationId() {
		return cancellationId;
	}

	public void setCancellationId(int cancellationId) {
		this.cancellationId = cancellationId;
	}

	public LocalDate getCancellationDate() {
		return cancellationDate;
	}

	public void setCancellationDate(LocalDate cancellationDate) {
		this.cancellationDate = cancellationDate;
	}

	public String getCancellationReason() {
		return cancellationReason;
	}

	public void setCancellationReason(String cancellationReason) {
		this.cancellationReason = cancellationReason;
	}

	public String getCancellationStatus() {
		return cancellationStatus;
	}

	public void setCancellationStatus(String cancellationStatus) {
		this.cancellationStatus = cancellationStatus;
	}

	public double getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(double refundAmount) {
		this.refundAmount = refundAmount;
	}

	@Override
	public String toString() {
		return "Cancellation [cancellationId=" + cancellationId + ", cancellationDate=" + cancellationDate
				+ ", cancellationReason=" + cancellationReason + ", cancellationStatus=" + cancellationStatus
				+ ", refundAmount=" + refundAmount + ", transaction=" + transaction + "]";
	}

}