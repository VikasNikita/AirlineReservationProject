package com.example.demo.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.Bookings;

@Repository
public class BookingRepoImple extends BaseRepository implements BookingRepository
{

	@Transactional
	public void insertBooking(Bookings bobj) {
		super.persist(bobj);
	}

	@Override
	public Bookings selectBooking(int bid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Bookings> selectCancellation() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateBookings(Bookings bobj) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteBookings(int bid) {
		// TODO Auto-generated method stub
		
	}

}
