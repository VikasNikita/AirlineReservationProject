package com.example.demo.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.Bookings;

@Repository
public class BookingRepoImple extends BaseRepository implements BookingRepository
{

	@Transactional
	public void insertBooking(Bookings bobj) {
		super.persist(bobj);
	}

	@Transactional
	public Bookings selectBooking(int bid) 
	{
		Bookings bookings=super.find(Bookings.class, bid);
		return bookings;
	}

	@Override
	public List<Bookings> selectBooking() {
		List<Bookings> bookingsList=super.findAll("Bookings");
		return bookingsList;
	}

	@Transactional
	public void updateBookings(Bookings bobj) {
		super.merge(bobj);
	}

	@Override
	public void deleteBookings(int bid) {
		// TODO Auto-generated method stub
		
	}

}

