package com.example.demo.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.Cancellation;

@Repository
public class CancellationRepoImpl extends BaseRepository implements CancellationRepo
{
	
	public CancellationRepoImpl() {
		super();
		System.out.println("CancellationRepoImple.............");
	}

	@Transactional
	public void insertCancellation(Cancellation cobj)
	{
		super.persist(cobj);
		System.out.println("Cancellation inserted:");
	}

	@Override
	public Cancellation selectCancellation(int cid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cancellation> selectCancellation() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateCancellation(Cancellation cobj) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteCancellation(int cid) {
		// TODO Auto-generated method stub
		
	}
	
}
