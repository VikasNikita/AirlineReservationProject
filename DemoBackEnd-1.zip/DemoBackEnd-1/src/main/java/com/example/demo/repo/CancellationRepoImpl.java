package com.example.demo.repo;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.Cancellation;

@Repository
public class CancellationRepoImpl extends BaseRepository implements CancellationRepo
{
	
	public CancellationRepoImpl() {
		super();
		System.out.println("CancellationRepoImple.............");
	}

	@Transactional
	public void insertCancellation(Cancellation cobj)
	{
		super.persist(cobj);
		System.out.println("Cancellation inserted:");
	}

	@Override
	public Cancellation selectCancellation(int cid) {
		Cancellation cancellation=super.find(Cancellation.class, cid);
		return cancellation;
	}

	@Override
	public List<Cancellation> selectCancellation() {
		List<Cancellation> cancellationsList=new ArrayList<Cancellation>();
		return super.findAll("Cancellation");
	}

	@Transactional
	public void updateCancellation(Cancellation cobj) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteCancellation(int cid) {
		// TODO Auto-generated method stub
		
	}
	
}
