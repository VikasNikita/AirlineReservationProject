package com.example.demo.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.Cancellation;

	@Repository
	public interface CancellationRepo {
		void insertCancellation(Cancellation cobj); //C
		
		Cancellation selectCancellation(int cid); //R
		List<Cancellation> selectCancellation(); //RA
		
		void updateCancellation(Cancellation cobj); //U
		void deleteCancellation(int cid); //D
		
	
}
