package com.example.demo.repo;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.entity.Flight;
@Repository
public class FlightRepositoryImpl extends BaseRepository implements FlightRepository
{
	

	public FlightRepositoryImpl() {
		super();
		System.out.println("FlightRepositoryImple...................");
	}

	@Transactional
	public void insertFlight(Flight fobj) {
		super.persist(fobj);
		System.out.println("Flight Inserted............................");
	}

	@Override
	public Flight selectFlight(int flightid) 
	{
		System.out.println("FlightRepositoryImple: select Department by flightid");
		Flight flight=super.find(Flight.class, flightid);
		return flight;
	}

	@Override
	public List<Flight> selectFlights() {
		List<Flight> flightsList=new ArrayList<Flight>();
		System.out.println("FlightRepositoryImpl:selecting all flights.......");
		return super.findAll("Flight");
	}

	@Override
	public void updateFlight(Flight fobj)
	{
		System.out.println("Flight RepositoryImple:Updating Flight");
		super.merge(fobj);
	}

	@Override
	public void deleteDepartment(int flightid) {
		System.out.println("FlightRepositoryImple: Deleting Flight ");
		super.remove(Flight.class, flightid);
		
	}
	
}
