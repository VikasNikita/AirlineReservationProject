package com.example.demo.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.entity.Flight;



@Repository
public interface FlightRepository {
	void insertFlight(Flight fobj); //C
	
	Flight selectFlight(int flightid); //R
	List<Flight> selectFlights(); //RA
	
	void updateFlight(Flight fobj); //U
	void deleteDepartment(int flightid); //D
	
}
