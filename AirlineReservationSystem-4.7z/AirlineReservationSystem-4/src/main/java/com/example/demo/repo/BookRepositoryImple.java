package com.example.demo.repo;

import java.util.ArrayList;
import java.util.List;

import com.example.demo.entity.Bookings;
import com.example.demo.entity.Flight;

public class BookRepositoryImple extends BaseRepository implements BookRepository
{
	
	public BookRepositoryImple() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void insertBooking(Bookings bobj) {
		super.persist(bobj);
		System.out.println("Bookings insert..........");
	}

	@Override
	public Bookings selectBooking(int bookingid) 
	{
		System.out.println("BookingsRepository : select Booking flight");
		Bookings booking=super.find(Bookings.class, bookingid);
		return booking;
	}

	@Override
	public List<Bookings> selectBooking()
	{
		List<Bookings> bookingsList=new ArrayList<Bookings>();
		System.out.println("BookingRepo: selection all bookings flight");
		return super.findAll("Bookings");
	}

}
