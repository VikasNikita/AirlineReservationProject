package com.example.demo.repo;

import java.util.List;

import com.example.demo.entity.Bookings;
import com.example.demo.entity.Flight;

public interface BookRepository 
{
	void insertBooking(Bookings bobj); //C
	Bookings selectBooking(int bookingid); //R
	List<Bookings> selectBooking(); //RA
	
}
