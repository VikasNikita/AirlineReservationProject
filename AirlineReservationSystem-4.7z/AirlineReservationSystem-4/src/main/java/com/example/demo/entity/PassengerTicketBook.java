package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="PassengerTickFlight")
public class PassengerTicketBook 
{
	@Id
//	@GeneratedValue
	@Column(name="TICKET_ID")
	private int TicketId;
	
	@ManyToOne
	@JoinColumn(name="Flight_ID")
	private Flight flight;
	
	//..................................Seat table mapping...................................
	@ManyToOne
	@JoinColumn(name="SEAT_NUMBER")
	private Seat seat;
	
	//.................................booking table mapping.....................................
	
	@ManyToOne
	@JoinColumn(name="BOOKINGID")
	Bookings bookings;
	
	//...............................................passenger table mapping
	
	@ManyToOne
	@JoinColumn(name = "PASSENGERID")
	private PassengerTable passengerTable;
	
	//................................Constructor.....................................
	
	

	public PassengerTicketBook() {
		super();
	}
	
	
	
	



	public PassengerTicketBook(int ticketId, Flight flight) {
		super();
		TicketId = ticketId;
		this.flight = flight;
	}







	public PassengerTicketBook(Seat seat) {
		super();
		this.seat = seat;
	}



	public PassengerTicketBook(Bookings bookings) {
		super();
		this.bookings = bookings;
	}



	

	public PassengerTicketBook(int ticketId, PassengerTable passengerTable) {
		super();
		TicketId = ticketId;
		this.passengerTable = passengerTable;
	}



	//.....................................GetterAndSetter..................................
	
	public Flight getFlight() {
		return flight;
	}



	public void setFlight(Flight flight) {
		this.flight = flight;
	}



	public Seat getSeat() {
		return seat;
	}



	public void setSeat(Seat seat) {
		this.seat = seat;
	}



	public PassengerTable getPassengerTable() {
		return passengerTable;
	}

	public void setPassengerTable(PassengerTable passengerTable) {
		this.passengerTable = passengerTable;
	}

	public int getTicketId() {
		return TicketId;
	}

	public void setTicketId(int ticketId) {
		TicketId = ticketId;
	}

	public Bookings getBookings() {
		return bookings;
	}

	public void setBookings(Bookings bookings) {
		this.bookings = bookings;
	}
	
	
	//.................................toString.........................................
	
	
	@Override
	public String toString() {
		return "PassengerTicketBook [TicketId=" + TicketId + ", bookings=" + bookings + "]";
	}
	
	
	
}
