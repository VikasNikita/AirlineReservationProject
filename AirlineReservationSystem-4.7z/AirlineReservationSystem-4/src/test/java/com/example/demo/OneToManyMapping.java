package com.example.demo;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Bookings;
import com.example.demo.entity.Flight;
import com.example.demo.repo.BookRepositoryImple;
import com.example.demo.repo.FlightRepositoryImpl;
@SpringBootTest
public class OneToManyMapping 
{
	@Autowired
	FlightRepositoryImpl flightRepo;
	
	@Autowired
	BookRepositoryImple bookRepositoryImple;
	
	@Test
	void InsertFlight() {
		LocalDateTime dateTime=LocalDateTime.of(2020, 12, 12, 3, 12,12);
		
		LocalDateTime localDateTime=LocalDateTime.of(2020,12,23,4,23,23);
		
//		Flight flight = new Flight(1,"AirlineIndia","Mumbai","Pune",dateTime,localDateTime,1200,1300,2,3,34,12);
//		flightRepo.insertFlight(flight);
		
		Flight flight1 = new Flight(2,"AirlineIndia","Mumbai","Pune",dateTime,localDateTime,1200,1300,2,3,34,12);
		flightRepo.insertFlight(flight1);

	
	}
	
	
	
	
}
