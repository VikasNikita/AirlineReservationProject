package com.example.demo.repo;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.CancellationTable;


@Repository
public class CancellationRepoImpl extends BaseRepository implements CancellationRepo
{
	
	public CancellationRepoImpl() {
		super();
		System.out.println("CancellationRepoImple.............");
	}

	@Transactional
	public void insertCancellation(CancellationTable cobj)
	{
		super.persist(cobj);
		System.out.println("Cancellation inserted:");
	}

	@Override
	public CancellationTable selectCancellation(int cid) {
		CancellationTable cancellation=super.find(CancellationTable.class, cid);
		return cancellation;
	}

	@Override
	public List<CancellationTable> selectCancellation() {
		List<CancellationTable> cancellationsList=new ArrayList<CancellationTable>();
		return super.findAll("CancellationTable");
	}

	@Transactional
	public void updateCancellation(CancellationTable cobj) {
		super.merge(cobj);
	}

	@Override
	public void deleteCancellation(int cid) {
		super.remove(CancellationTable.class,cid );
	}
	
}
