package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.modal.Flight;

@Service
public interface FlightService 
{
	public List<Flight> getFlightDetails();
	public void insertFlight(Flight flight);
	public void updateFlightDetails(int id,Flight flight);
	public void deleteFlightDetails(int id);
}
