package com.example.demo.modal;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Seat01")
public class Seat
{
	@Id
	@GeneratedValue
	@Column(name="SEAT_NUMBER")
	private int seatNumber;
	
	@Column(name="SEAT_TYPE")
	private String seatType;
	
	
	//Mapping Seat................................................
	
	@OneToMany(cascade = CascadeType.ALL,mappedBy = "seat")
	private Set<PassengerTicketBook> passengerTicketBook;
	
	//.............................Constructor...............................

	public Seat() {
		super();
	}
	
	
	public Seat(int seatNumber, String seatType, Set<PassengerTicketBook> passengerTicketBook) {
		super();
		this.seatNumber = seatNumber;
		this.seatType = seatType;
		this.passengerTicketBook = passengerTicketBook;
	}

//.............................................gettterandsetter....................................
	public int getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}

	public String getSeatType() {
		return seatType;
	}

	public void setSeatType(String seatType) {
		this.seatType = seatType;
	}

	public Set<PassengerTicketBook> getPassengerTicketBook() {
		return passengerTicketBook;
	}

	public void setPassengerTicketBook(Set<PassengerTicketBook> passengerTicketBooksSet) {
		this.passengerTicketBook = passengerTicketBooksSet;
	}

	//....................................toString..........................................
	
	@Override
	public String toString() {
		return "Seat [seatNumber=" + seatNumber + ", seatType=" + seatType + ", passengerTicketBook="
				+ passengerTicketBook + "]";
	}
	
	
	
}