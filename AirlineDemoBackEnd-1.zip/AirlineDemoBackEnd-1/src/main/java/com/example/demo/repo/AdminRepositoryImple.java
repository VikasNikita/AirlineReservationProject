package com.example.demo.repo;

import java.util.List;

import javax.persistence.NoResultException;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.Admin;
import com.example.demo.modal.Flight;

@Repository
public class AdminRepositoryImple extends BaseRepository implements AdminRepository
{



	@Transactional
	public void addFlight(Flight newFlight) {
		super.persist(newFlight);
	}

	@Transactional
	public void deleteFlight(int flightId) {
		super.remove(Flight.class, flightId);
		
	}

	@Transactional
	public void updateFlight(Flight fobj) {
		super.merge(fobj);
	}

//	@Transactional
//	public boolean loginAdmin(Admin adminAccount)
//	{
//		
//		Admin admin=null;
////		admin.setAdminEmailId(adminAccount.getAdminEmailId());
////		admin.setAdminPassward(adminAccount.getAdminPassward());
//		try {
//		if(admin==null)
//		{
//			return false;
//		}
//		else if(admin.getAdminPassward().equals(adminAccount.getAdminPassward()) && admin.getAdminEmailId().equals(adminAccount.getAdminEmailId())) {
//			System.out.println("Admin Login Succesfully");
//			return true;
//			
//		}
//		else
//		{
//			return false;
//		}
//		}
//		catch (NoResultException e)
//		{
//			return false;
//		}
//		catch (Exception e) {
//			e.printStackTrace();
//			return false;
//		}
//	}

	@Transactional
	public void insertAdmin(Admin aobj) {
		super.persist(aobj);
	}
	
}
