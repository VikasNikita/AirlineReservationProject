package com.example.demo.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.CancellationTable;


	@Repository
	public interface CancellationRepo {
		void insertCancellation(CancellationTable cobj); //C
		
		CancellationTable selectCancellation(int cid); //R
		List<CancellationTable> selectCancellation(); //RA
		
		void updateCancellation(CancellationTable cobj); //U
		void deleteCancellation(int cid); //D
		
	
}
