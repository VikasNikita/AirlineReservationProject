package com.example.demo.repo;


import org.springframework.stereotype.Repository;
import com.example.demo.modal.Admin;
import com.example.demo.modal.Flight;

@Repository
public interface AdminRepository 
{
	void insertAdmin(Admin aobj); //C
//	Admin selectAdmin(int aid); //R
//	List<Admin> selectAdmin(); //RA
//	
//	void updateAdmin(Admin aobj); //U
//	void deleteAdmin(int aid);
	
	void addFlight (Flight newFlight);
	void deleteFlight(int flightId);
	void updateFlight(Flight fobj); 
//	public boolean loginAdmin (Admin adminAccount);
}
