package com.example.demo;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.modal.Bookings;
import com.example.demo.modal.Flight;
import com.example.demo.modal.PassengerTable;
import com.example.demo.modal.PassengerTicketBook;
import com.example.demo.modal.Seat;
import com.example.demo.modal.User;
import com.example.demo.repo.BookingRepoImple;
import com.example.demo.repo.PassengerRepositoryImple;
import com.example.demo.repo.PassengerTicketBookRepo;
import com.example.demo.repo.SeatRepository;
import com.example.demo.repo.UserRepositoryImple;
@SpringBootTest
public class UserTestCases 
{
	@Autowired
	UserRepositoryImple UserRepo;
	
	@Autowired
	BookingRepoImple bookingRepo;
	
	@Autowired
	PassengerRepositoryImple passenRepo;
	
	@Autowired
	SeatRepository seatRepo;
	
	@Autowired
	PassengerTicketBookRepo passengertiRepo;
	
	@Test
	void userInsert()
	{
			User user=new User();
		
			user.setUserId(43);
			user.setFirstName("Nikita");
			user.setLastName("BHavsar");
			user.setEmailId("nikita@123gmail.com");
			user.setPassward("123");
			user.setDob(LocalDate.of(1997,7, 31));
			user.setMobNumber(345678);
			UserRepo.insertUser(user);
	}
	@Test
	void createBookingtest() {
		User user = UserRepo.selectUser(43);
		
		
		Bookings bookings = new Bookings();
		LocalDate date = LocalDate.now();
		bookings.setBookingId(35);
		bookings.setBusinessSeatsBooked(12);
		bookings.setEconomySeatsBooked(12);
		bookings.setBookingDate(date);
		bookings.setJourneyType("Within Country");
		bookings.setTotalCost(3000);
		bookings.setUser(user);
		bookingRepo.insertBooking(bookings);
		
		Bookings bookings1 = new Bookings();

		LocalDate date1 = LocalDate.now();
		bookings1.setBookingId(36);
		bookings1.setBookingStatus("Succ");
		bookings1.setBusinessSeatsBooked(12);
		bookings1.setEconomySeatsBooked(12);
		bookings1.setBookingDate(date1);
		bookings1.setJourneyType("Within Country");
		bookings1.setTotalCost(3000);
		bookings1.setUser(user);
		bookingRepo.insertBooking(bookings1);
	}
	
	@Test
	void insertPassengerTable()
	{
		User user=UserRepo.selectUser(43);
		LocalDate localDate=LocalDate.of(1997, 12, 12);
		PassengerTable passengerTable=new PassengerTable();
		passengerTable.setPassengerId(51);
		passengerTable.setFirstName("Nikita");
		passengerTable.setGender("female");
		passengerTable.setDateOfBirth(localDate);
		passengerTable.setUser(user);
		passenRepo.insertPassengerTable(passengerTable);
		
	}
	
	@Test
	void insertseat()
	{
		Seat seat=new Seat();
		seat.setSeatNumber(71);
		seat.setSeatType("Economic");
		seatRepo.save(seat);
	}
	
	@Test
	void insertPassengerwithPassengerTicketBook()
	{
		
		PassengerTicketBook passengerTicketBook= 
	}
	
}
