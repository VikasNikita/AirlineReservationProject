package com.example.demo.repo;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.example.demo.modal.PassengerTable;

@Repository
public class PassengerRepositoryImple extends BaseRepository implements PassengerTableRepository 
{

	@Transactional
	public void insertPassengerTable(PassengerTable pobj) {
		super.persist(pobj);
		
	}

	@Override
	public PassengerTable selectPassenger(int pid) {
		PassengerTable passengerTable=super.find(PassengerTable.class, pid);
		return passengerTable;
	}

	@Override
	public List<PassengerTable> selectPassengerTable() {
		List<PassengerTable> list=super.findAll("PassengerTable");
		return list;
	}

	@Transactional
	public void updatePassengerTable(PassengerTable pobj) {
		super.merge(pobj);
		
	}

	@Transactional
	public void deletePassengerTable(int pid) {
		super.remove(PassengerTable.class, pid);	
	}
	
}
