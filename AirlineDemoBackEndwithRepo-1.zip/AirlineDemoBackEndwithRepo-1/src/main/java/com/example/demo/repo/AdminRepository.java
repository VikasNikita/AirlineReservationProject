package com.example.demo.repo;

import java.util.List;

import org.springframework.stereotype.Repository;
import com.example.demo.modal.Admin;

@Repository
public interface AdminRepository 
{
	void insertAdmin(Admin aobj); //C
	Admin selectAdmin(int aid); //R
	List<Admin> selectAdmin(); //RA
	
	void updateAdmin(Admin aobj); //U
	void deleteAdmin(int aid);
}
