package com.example.demo.repo;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.example.demo.modal.Flight;

@Repository
public interface FlightRepository {
	void insertFlight(Flight fobj); 
	Flight selectFlight(int fid); 
	List<Flight> selectFlight(); 
	void updateFlight(Flight fobj); 
	void deleteFlight(int fid); 
}
