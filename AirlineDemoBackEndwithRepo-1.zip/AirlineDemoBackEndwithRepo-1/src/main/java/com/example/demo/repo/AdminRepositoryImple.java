package com.example.demo.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.Admin;

@Repository
public class AdminRepositoryImple extends BaseRepository implements AdminRepository
{

	@Transactional
	public void insertAdmin(Admin aobj) {
		super.persist(aobj);
		
	}

	@Override
	public Admin selectAdmin(int aid) {
		Admin admin=super.find(Admin.class, aid);
		return admin;
	}

	@Override
	public List<Admin> selectAdmin() {
		List<Admin> admins=super.findAll("Admin");
		return admins;
	}

	@Transactional
	public void updateAdmin(Admin aobj) {
		super.merge(aobj);
		
	}

	@Transactional
	public void deleteAdmin(int aid) {
		super.remove(Admin.class, aid);
	}
	
}
