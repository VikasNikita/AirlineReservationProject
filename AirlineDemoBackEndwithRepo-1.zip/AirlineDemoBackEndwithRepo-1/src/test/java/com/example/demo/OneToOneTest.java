package com.example.demo;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.modal.Bookings;
import com.example.demo.modal.CancellationTable;
import com.example.demo.modal.TransactionTable;
import com.example.demo.repo.BookingRepoImple;
import com.example.demo.repo.CancellationRepoImpl;
import com.example.demo.repo.TransactionRepoImple;

@SpringBootTest
public class OneToOneTest
{
	@Autowired
	TransactionRepoImple tranrepo;
	
	@Autowired
	CancellationRepoImpl canrepo;
	
	
	@Autowired
	BookingRepoImple bookRepo;
	
	@Test
	void insertTranTest()
	{
		TransactionTable tran=new TransactionTable();
		tran.setTrannsactionId(3);
		tran.setTransactionType("Online");
		tran.setTransactionAmount(12000.0f);
		tran.setTransactionMode("succ");
		tran.setTransactionStatus("active");
		tranrepo.insertTransaction(tran);
		
		
		
		
		TransactionTable tran1=new TransactionTable();
		tran1.setTrannsactionId(4);
		tran1.setTransactionType("Online");
		tran1.setTransactionAmount(12000.0f);
		tran1.setTransactionMode("succ");
		tran1.setTransactionStatus("active");
		tranrepo.insertTransaction(tran1);
	}
	
	
	@Test
	void selectTranTest()
	{
		TransactionTable transaction;
		transaction=tranrepo.selectTransaction(3);

		System.out.println("Transaction id: "+transaction.getTrannsactionId());
		System.out.println("Transaction Type :"+transaction.getTransactionType());
		System.out.println("Transaction Amount: "+transaction.getTransactionMode());
		System.out.println("Transaction Status:"+transaction.getTransactionStatus());
		
	
	}
	@Test
	void selectAllTransTest()
	{
		List<TransactionTable> tranList;
		tranList=tranrepo.selectTransactions();
		for(TransactionTable transaction : tranList)
		{
			System.out.println("Transaction id: "+transaction.getTrannsactionId());
			System.out.println("Transaction Type :"+transaction.getTransactionType());
			System.out.println("Transaction Amount: "+transaction.getTransactionMode());
			System.out.println("Transaction Status:"+transaction.getTransactionStatus());
		}
	}
	
	@Test
	void insertCanTest()
	{
		LocalDate localDate=LocalDate.of(2020, 12, 12);
		
		CancellationTable can=new CancellationTable();
		can.setCancellationId(11);
		can.setCancellationReason("Some issue");
		can.setCancellationStatus("succ");
		can.setRefundAmount(12000.0f);
		can.setCancellationDate(localDate);
	
		CancellationTable cancellation=new CancellationTable();
		cancellation.setCancellationId(12);
		cancellation.setCancellationReason("Some issue");
		cancellation.setCancellationStatus("succ");
		cancellation.setRefundAmount(12000.0f);
		cancellation.setCancellationDate(localDate);
		
		canrepo.insertCancellation(can);
		canrepo.insertCancellation(cancellation);
		
		
	}
	@Test
	void assignExistingTransactionToExistingCancellation()
	{
		TransactionTable transaction=tranrepo.find(TransactionTable.class,3 );
		CancellationTable cancellation=canrepo.find(CancellationTable.class, 12);
		
		transaction.setCancellationTable(cancellation);
		cancellation.setTransactionTable(transaction);
		
		tranrepo.merge(cancellation);
		canrepo.merge(transaction);
	}
	
	@Test
	void selectCanTest()
	{
		CancellationTable can;
		can=canrepo.selectCancellation(11);

		System.out.println("Cancellation id: "+can.getCancellationId());
		System.out.println("Cancellation date:"+can.getCancellationDate());
		System.out.println("Cancellation reason: "+can.getCancellationReason());
		System.out.println("Cancellation status: "+can.getCancellationStatus());
		System.out.println("Cancellation Refund:"+can.getRefundAmount());
	
	}
	
	@Test
	void selectAllCanTest()
	{
		List<CancellationTable> canList;
		canList=canrepo.selectCancellation();
		for(CancellationTable can : canList)
		{
			System.out.println("Cancellation id: "+can.getCancellationId());
			System.out.println("Cancellation date:"+can.getCancellationDate());
			System.out.println("Cancellation reason: "+can.getCancellationReason());
			System.out.println("Cancellation status: "+can.getCancellationStatus());
			System.out.println("Cancellation Refund:"+can.getRefundAmount());
		}
	}
//		@Test
//		public void insertNewCancellationForExistingTransaction() {
//			
//				TransactionTable transaction = tranrepo.find(TransactionTable.class, 3);
//				
//			
//				CancellationTable cancellation = new CancellationTable(); //new object 
//				cancellation.setCancellationId(17);
//				cancellation.setCancellationReason("Some problem");
//				cancellation.setCancellationStatus("active");
//				cancellation.setCancellationDate(LocalDate.now());
//				cancellation.setRefundAmount(1300.0f);
//				
//				transaction.setCancellationTable(cancellation); 
//				cancellation.setTransactionTable(transaction); 
//				
//				canrepo.merge(cancellation); 
//				tranrepo.persist(transaction);
//			
//	}
//		@Test
//		public void insertNewTranscationForExistingBooking() {
//			
//				Bookings booking = bookRepo.find(Bookings.class, 31);
//				
//			
//				TransactionTable transaction=new TransactionTable();
//				transaction.setTrannsactionId(5);
//				transaction.setTransactionMode("succ");
//				transaction.setTransactionAmount(12000);
//				transaction.setTransactionType("Online");
//				transaction.setTransactionStatus("active");
//				
//				transaction.setBookings(booking); 
//				booking.setTransactionTable(transaction); 
//				
//				bookRepo.persist(booking); 
//				tranrepo.merge(transaction);
//			
//			
//		
//	}
}
