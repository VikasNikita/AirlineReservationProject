package com.example.demo;

import java.time.LocalDate;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.modal.PassengerTable;
import com.example.demo.modal.Seat;
import com.example.demo.modal.User;
import com.example.demo.repo.PassengerRepositoryImple;
import com.example.demo.repo.SeatRepo;
import com.example.demo.repo.UserRepositoryImple;

@SpringBootTest
public class UserTestCases 
{
	@Autowired
	UserRepositoryImple userRepo;
	
	@Autowired
	PassengerRepositoryImple passengerRepo;
	
	@Autowired
	SeatRepo seatRepo;
	
	
	@Test
	void userInsert()
	{
			User user=new User();
		
			user.setFirstName("Nikita");
			user.setLastName("BHavsar");
			user.setEmailId("nikita@123gmail.com");
			user.setPassward("123");
			user.setDob(LocalDate.of(1997,7, 31));
			user.setMobNumber(345678);
			userRepo.insertUser(user);

	}
	
	@Test
	void insertPassengerTable()
	{
		User user=userRepo.selectUser(83);
		
		LocalDate localDate=LocalDate.of(1997, 12, 12);
		
		PassengerTable passengerTable=new PassengerTable();
		passengerTable.setFirstName("Nikita");
		passengerTable.setGender("female");
		passengerTable.setDateOfBirth(localDate);
		passengerTable.setUser(user);
		passengerRepo.insertPassengerTable(passengerTable);
		
		
	}
	
	@Test
	void insertseat()
	{
		Seat seat=new Seat();
//		seat.setSeatNumber(89);
		seat.setSeatType("Economic");
		seatRepo.save(seat);
	}
	
}
