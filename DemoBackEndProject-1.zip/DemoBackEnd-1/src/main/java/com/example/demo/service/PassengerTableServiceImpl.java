package com.example.demo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.modal.PassengerTable;
import com.example.demo.repo.PassengerRepositoryImple;

@Service
public class PassengerTableServiceImpl implements PassengerTableService
{
	@Autowired
	PassengerRepositoryImple passRepo;
	
	@Override
	public List<PassengerTable> getPassengerDetails() {
		return passRepo.selectPassengerTable();
	}

	@Override
	public void insertPassenger(PassengerTable passengerTable) {
		passRepo.persist(passengerTable);
	}

	@Override
	public void updatePassengerDetails(int id, PassengerTable passengerTable) {
		passengerTable.setPassengerId(id);
		passRepo.persist(passengerTable);
	}

	@Transactional
	public void deletePassengerDetails(int id) {
		passRepo.deletePassengerTable(id);
	}

}
