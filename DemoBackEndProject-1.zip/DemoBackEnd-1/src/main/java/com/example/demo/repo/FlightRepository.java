package com.example.demo.repo;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.example.demo.modal.Flight;

@Repository
public interface FlightRepository 
{
	Flight selectFlights(int fid); 
	List<Flight> FetchAllFlight(); 
	void updateFlight(Flight fobj);
	void deleteFlight(int fid); 
	 void insertFlight(Flight fobj) ;
}
