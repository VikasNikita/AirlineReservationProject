 package com.example.demo.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.TransactionTable;


@Repository
public interface TransactionRepo 
{
	void insertTransaction(TransactionTable tobj); 
	TransactionTable selectTransaction(int tid); 
	List<TransactionTable> selectTransactions(); 
	void updateTransaction(TransactionTable dobj); 
	void deleteTransaction(int tid); 
	
}
