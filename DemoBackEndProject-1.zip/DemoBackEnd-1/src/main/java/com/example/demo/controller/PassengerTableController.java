package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.modal.PassengerTable;
import com.example.demo.repo.PassengerRepositoryImple;

@RestController
@RequestMapping("/passenger")
public class PassengerTableController 
{
	@Autowired
	PassengerRepositoryImple passengerRepo;
	
	@GetMapping("get/{pid}")
	public PassengerTable getPassengerTable(@PathVariable ("pid") int pid)
	{
		PassengerTable passengerTable;
		passengerTable=passengerRepo.selectPassenger(pid);
		return passengerTable;
	}
	
	@GetMapping("/getAll")
	public List<PassengerTable> getPassengerTables()
	{
		List<PassengerTable> passengerlist;
		passengerlist=passengerRepo.selectPassengerTable();
		return passengerlist;
	}
	
	@PostMapping("/add")
	public void addPassengerTable(@RequestBody PassengerTable passengerTable)
	{
		passengerRepo.insertPassengerTable(passengerTable);
	}
	
	@PutMapping("/update")
	public void updatePassengerTable(@RequestBody PassengerTable passengerTable)
	{
		passengerRepo.updatePassengerTable(passengerTable);
	}
	
	@DeleteMapping("/delete/{pid}")
	public String deletePassengerTable(@PathVariable ("pid") int pid)
	{
		passengerRepo.deletePassengerTable(pid);
		return "delete succesfully";
	}
}
