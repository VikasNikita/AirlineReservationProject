package com.example.demo.repo;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.User;
@Repository
public class UserRepositoryImple extends  BaseRepository implements UserRepository
{

	@Transactional
	public void insertUser(User uobj) {
		super.persist(uobj);
	}

	@Override
	public User selectUser(int uid)
	{
		User user=super.find(User.class, uid);
		return user;
	}

	@Override
	public List<User> selectUsers() {
		List<User> usersList=new ArrayList<User>();
		return super.findAll("User");
	}

	@Transactional
	public void updateUser(User uobj) {
		super.merge(uobj);
	}

	@Transactional
	public void deleteUser(int uid) {
		super.remove(User.class, uid);
	}

	
}
