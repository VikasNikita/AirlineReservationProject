package com.example.demo.repo;


import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.example.demo.modal.Admin;
import com.example.demo.modal.Flight;

@Repository
public class AdminRepositoryImple extends BaseRepository implements AdminRepository
{



	@Transactional
	public void addFlight(Flight newFlight) {
		super.persist(newFlight);
	}

	@Transactional
	public void deleteFlight(int flightId) {
		super.remove(Flight.class, flightId);
		
	}

	@Transactional
	public void updateFlight(Flight fobj) {
		super.merge(fobj);
	}


	@Transactional
	public void insertAdmin(Admin aobj) {
		super.persist(aobj);
	}
	
}
