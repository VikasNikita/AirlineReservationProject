package com.example.demo.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.CancellationTable;


	@Repository
	public interface CancellationRepo
	{
		void insertCancellation(CancellationTable cobj); 
		CancellationTable selectCancellation(int cid); 
		List<CancellationTable> selectCancellation(); 
		void updateCancellation(CancellationTable cobj); 
		void deleteCancellation(int cid); 
		
	
}
