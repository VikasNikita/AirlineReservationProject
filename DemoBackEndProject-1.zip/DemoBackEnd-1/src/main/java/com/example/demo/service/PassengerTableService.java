package com.example.demo.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.example.demo.modal.PassengerTable;


@Service
public interface PassengerTableService
{
	public List<PassengerTable> getPassengerDetails();
	public void insertPassenger(PassengerTable passengerTable);
	public void updatePassengerDetails(int id,PassengerTable passengerTable);
	public void deletePassengerDetails(int id);
}
