package com.example.demo.service;
/*
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.modal.Admin;
import com.example.demo.repo.AdminRepositoryImple;

public class AdminServiceImpl implements AdminService {

	@Autowired
	AdminRepositoryImple adminRepo;
	
//	@Override
//	public List<Admin> getAdminDetails() {
//		// TODO Auto-generated method stub
//		return adminRepo.;
//	}

	@Override
	public void insertAdmin(Admin admin) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateAdminDetails(int id, Admin admin) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAdminDetails(int id) {
		// TODO Auto-generated method stub
		
	}

}
*/