package com.example.demo.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Admin1")
public class Admin 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ADMIN_ID")
	private int adminId;
	
	
	@Column(name="ADMIN_EMAIL")
	private String adminEmailId;
	
	@Column(name = "ADMIN_PASSWARD")
	private String adminPassward;
	
	//................................Constructor.........................
	public Admin() {
		super();
	}
	
	
	public Admin(String adminEmailId, String adminPassward) {
		super();
		this.adminEmailId = adminEmailId;
		this.adminPassward = adminPassward;
	}


	public Admin(int adminId, String adminEmailId, String adminPassward) {
		super();
		this.adminId = adminId;
		this.adminEmailId = adminEmailId;
		this.adminPassward = adminPassward;
	}


	//....................................getter and setter
	
	public int getAdminId() {
		return adminId;
	}

	public String getAdminEmailId() {
		return adminEmailId;
	}


	public void setAdminEmailId(String adminEmailId) {
		this.adminEmailId = adminEmailId;
	}


	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getAdminPassward() {
		return adminPassward;
	}

	public void setAdminPassward(String adminPassward) {
		this.adminPassward = adminPassward;
	}
	//.........................................toString..........................
	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", adminPassward=" + adminPassward + "]";
	}
	
	
}
