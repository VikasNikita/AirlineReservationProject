//package com.example.demo.repo;
//
//import org.springframework.stereotype.Repository;
//
//import com.example.demo.modal.Seat;
//@Repository
//public class SeatRepositoryImple extends BaseRepository implements SeatRepo
//{
//
//	
//	@Override
//	public void insertSeatTest(Seat sobj)
//	{
//		System.out.println("SeatRepoImple:");
//		super.persist(sobj);
//	}
//
//}
