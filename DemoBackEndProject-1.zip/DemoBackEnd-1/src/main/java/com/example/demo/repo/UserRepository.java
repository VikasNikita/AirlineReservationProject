package com.example.demo.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.Admin;
import com.example.demo.modal.User;

@Repository
public interface UserRepository 
{
	void insertUser(User uobj); 
	User selectUser(int uid); 
	List<User> selectUsers(); 
	void updateUser(User uobj); 
	void deleteUser(int uid);

}
