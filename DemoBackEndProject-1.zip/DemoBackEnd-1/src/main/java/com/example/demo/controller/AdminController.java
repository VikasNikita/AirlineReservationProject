package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.modal.Admin;
import com.example.demo.repo.AdminRepositoryImple;


@RestController
@RequestMapping("/admin")
public class AdminController
{
	
	
	@Autowired
	AdminRepositoryImple adminRepo;
	
//	@GetMapping("/get/{aid}")
//	public Flight getadmin(@PathVariable("aid") int aid)
//	{
//		Admin admin;
//		admin=adminRepo.select(fid);
//		return flight;
//	}
//	//http://localhost:8080/dept/getAll
//	//http://localhost:8080/dept/getAll
//	
//	@GetMapping("/getAll")
//	public List<Flight> getFlights()
//	{
//		List<Flight> flightList;
//		flightList=flightRepo.FetchAllFlight();
//		return flightList;
//	}
//	
	
	@PostMapping("/add")
	public void add(@RequestBody Admin admin)
	{
		adminRepo.insertAdmin(admin);
	}
	
	
//	@PutMapping("/update")
//	public void updateFlight(@RequestBody Flight flightObj)
//	{
//		flightRepo.updateFlight(flightObj);
//	}
//	
//	@DeleteMapping("/delete/{fid}")
//	public String deleteFlight(@PathVariable("fid") int fid)
//	{
//		flightRepo.deleteFlight(fid);
//		return "delete successfully";
//	}
}	
	