package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.modal.Bookings;
import com.example.demo.modal.Flight;

@Service
public interface BookingService 
{
	public List<Bookings> getBookingDetails();
	public void insertFlight(Bookings bookings);
	public void updateBookingDetails(int id,Bookings bookings);
	public void deleteBookingsDetails(int id);
}
