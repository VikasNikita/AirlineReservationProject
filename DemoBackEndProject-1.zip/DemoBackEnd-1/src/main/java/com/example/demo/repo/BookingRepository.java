package com.example.demo.repo;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.example.demo.modal.Bookings;

@Repository
public interface BookingRepository
{
	void insertBooking(Bookings bobj); 
	
	Bookings selectBooking(int bid); 
	List<Bookings> selectBooking(); 
	
	void updateBookings(Bookings bobj); 
	void deleteBookings(int bid);
}

