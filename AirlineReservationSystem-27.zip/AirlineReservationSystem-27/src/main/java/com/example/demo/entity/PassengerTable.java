package com.example.demo.entity;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="PassengerTables")
public class PassengerTable
{
	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="PASSENGERID")
	private int passengerId;
	
	private String firstName;
	
	private String lastName;
	
	private String gender;
	
	private LocalDate dateOfBirth;
	
	//........................Mapping User..............................................
	
	@ManyToOne
	@JoinColumn(name="USER_ID")
	private User user;
	
	//......................MappingPassengerTicketBook.......................

	@OneToMany(cascade = CascadeType.ALL,mappedBy = "passengerTable")
	private Set<PassengerTicketBook> passengerTicketBooks=new HashSet<PassengerTicketBook>();
	
	//..................................Constructor...........................
	
	public PassengerTable() {
		super();
	}

	public PassengerTable(int passengerId, String firstName, String lastName, String gender, LocalDate dateOfBirth,
			User user) {
		super();
		this.passengerId=passengerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.dateOfBirth = dateOfBirth;
		this.user = user;
	}
	
	
	//........................................GetterAndSetter...................................
	
	
	
	public Set<PassengerTicketBook> getPassengerTicketBooks() {
		return passengerTicketBooks;
	}

	public void setPassengerTicketBooks(Set<PassengerTicketBook> passengerTicketBooks) {
		this.passengerTicketBooks = passengerTicketBooks;
	}

	public int getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(int passengerId) {
		this.passengerId = passengerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	//.............................toSTring.............................
	
	@Override
	public String toString() {
		return "PassengerTable [passengerId=" + passengerId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", gender=" + gender + ", dateOfBirth=" + dateOfBirth + ", user=" + user + "]";
	}
	
	
}
