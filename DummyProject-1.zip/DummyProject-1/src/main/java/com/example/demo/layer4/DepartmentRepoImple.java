package com.example.demo.layer4;

import java.util.ArrayList;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Department;

@Repository
public class DepartmentRepoImple extends BaseRepository implements DepartmentRepo
{

	@Transactional
	public void insertDepartment(Department dobj) {
		super.persist(dobj);
	}

	@Override
	public Department selectDepartment(int dno) {
		Department department=super.find(Department.class, dno);
		return department;
	}

	@Override
	public List<Department> selectDepartments() {
		List<Department> list=super.findAll("Department");
		return list;
	}

	@Transactional
	public void updateDepartment(Department dobj) {
		super.merge(dobj);
	}

	@Transactional
	public void deleteDepartment(int dno) {
		// TODO Auto-generated method stub
		super.remove(Department.class, dno);
	}

}
