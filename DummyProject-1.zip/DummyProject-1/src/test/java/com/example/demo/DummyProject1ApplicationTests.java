package com.example.demo;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Department;
import com.example.demo.layer4.DepartmentRepoImple;

@SpringBootTest
class DummyProject1ApplicationTests {

	@Autowired
	DepartmentRepoImple deptRepo;
	
	@Test
	void contextLoads() {
	}
	
	@Test
	void insertDeptTest()
	{
		Department dept=new Department();
		System.out.println("InsertDept");
//		dept.setDeptId(390);
		dept.setDeptName("QA");
		dept.setDeptLocation("Pune");
		deptRepo.insertDepartment(dept);
	}
	@Test
	void selectAllDeptTest()
	{
		List<Department> deptList;
		deptList=deptRepo.selectDepartments();
		for (Department dept : deptList)
		{
			System.out.println("dept no: "+dept.getDeptId());
			System.out.println("dept Name: "+dept.getDeptName());
			System.out.println("dept Location :"+dept.getDeptLocation());
		}
	}
	
	
}
