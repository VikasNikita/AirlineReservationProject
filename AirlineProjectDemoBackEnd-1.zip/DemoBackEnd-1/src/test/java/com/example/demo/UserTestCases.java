package com.example.demo;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.modal.User;
import com.example.demo.repo.UserRepositoryImple;
@SpringBootTest
public class UserTestCases 
{
	@Autowired
	UserRepositoryImple UserRepo;
	
	@Test
	void userInsert()
	{
			User user=new User();
		
			user.setUserId(43);
			user.setFirstName("Nikita");
			user.setLastName("BHavsar");
			user.setEmailId("nikita@123gmail.com");
			user.setPassward("123");
			user.setDob(LocalDate.of(1997,7, 31));
			user.setMobNumber(345678);
			UserRepo.insertUser(user);
	}
	
}
