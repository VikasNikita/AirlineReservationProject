package com.example.demo;


import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.modal.Bookings;
import com.example.demo.modal.Flight;
import com.example.demo.modal.TransactionTable;
import com.example.demo.repo.BookingRepoImple;
import com.example.demo.repo.FlightRepositoryImple;
import com.example.demo.repo.TransactionRepoImple;

@SpringBootTest
public class BookingFlightTest
{
	@Autowired
	FlightRepositoryImple flightRepo;
	
	@Autowired
	BookingRepoImple bookingRepo;
	
	@Autowired
	TransactionRepoImple tranRepo;
	
	@Test
	void createBookingtest() {
		Flight flight = flightRepo.selectFlights(21);
		
		
		Bookings bookings = new Bookings();
		LocalDate date = LocalDate.now();
		bookings.setBookingId(31);
		bookings.setBusinessSeatsBooked(12);
		bookings.setEconomySeatsBooked(12);
		bookings.setBookingDate(date);
		bookings.setJourneyType("Within Country");
		bookings.setTotalCost(3000);
		bookings.setFlight(flight);
		bookingRepo.insertBooking(bookings);
		
		
		Bookings bookings1 = new Bookings();
		LocalDate date1 = LocalDate.now();
		bookings1.setBookingId(32);
		bookings1.setBusinessSeatsBooked(12);
		bookings1.setEconomySeatsBooked(12);
		bookings1.setBookingDate(date1);
		bookings1.setJourneyType("One_Way");
		bookings1.setTotalCost(3000);
		bookings1.setFlight(flight);
		bookingRepo.insertBooking(bookings1);
		System.out.println("Flight Booked Succesfully");
	}
	
	@Test
	void updateBookFlightTest()
	{
		Flight flight=flightRepo.selectFlights(21);
		LocalDate date1 = LocalDate.now();
		Bookings bookings=new Bookings(32,21, 21,date1,"Succ","One Way", 2000,flight);
		bookingRepo.updateBookings(bookings);
		System.out.println("Book flight Updated Succesfully...................");
	}
	
	@Test
	void getselectBookingTest()
	{
		Bookings  booking;
		booking=bookingRepo.selectBooking(31);
		System.out.println("Booking id: "                 	  +booking.getBookingId());
		System.out.println("booking EconomySeatBook : "       +booking.getEconomySeatsBooked());
		System.out.println("booking business seat book :"     +booking.getBusinessSeatsBooked());
		System.out.println("booking date:"                    +booking.getBookingDate());
		System.out.println("booking status :"                 +booking.getBookingStatus());
		System.out.println("booking Journey type :"           +booking.getJourneyType());
		System.out.println("booking economy seat price :"     +booking.getTotalCost());
		System.out.println("Booking Select Succesfully");
	}
	
	@Test
	void selectAllBookTest()
	{
		List<Bookings> bookingList;
		bookingList=bookingRepo.selectBooking();
		for (Bookings booking : bookingList)
		{
			System.out.println("Booking id: "                 	  +booking.getBookingId());
			System.out.println("booking EconomySeatBook : "       +booking.getEconomySeatsBooked());
			System.out.println("booking business seat book :"     +booking.getBusinessSeatsBooked());
			System.out.println("booking date:"                    +booking.getBookingDate());
			System.out.println("booking status :"                 +booking.getBookingStatus());
			System.out.println("booking Journey type :"           +booking.getJourneyType());
			System.out.println("booking economy seat price :"     +booking.getTotalCost());
			System.out.println("All Flights Selected Succesfully");
		}
	}
		
//		@Test
//		void assignExistingTransactionToExistingBooking()
//		{
//			TransactionTable transaction=tranRepo.find(TransactionTable.class,1 );
//			Bookings booking=bookingRepo.find(Bookings.class, 31);
//			
//			transaction.(booking);
//			booking.setTransactionTable(transaction);
//			
//			tranRepo.merge(booking);
//			bookingRepo.merge(transaction);
//		
//		
//	}
}

