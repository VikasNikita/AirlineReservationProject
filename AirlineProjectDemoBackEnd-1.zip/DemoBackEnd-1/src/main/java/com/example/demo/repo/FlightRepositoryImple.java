package com.example.demo.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.Flight;

@Repository
public class FlightRepositoryImple extends BaseRepository implements FlightRepository
{

	@Transactional
	public void insertFlight(Flight fobj) {
		super.persist(fobj);
	}

	@Override
	public Flight selectFlights(int fid) {
			Flight flight=super.find(Flight.class, fid);
		return flight;
	}

	@Override
	public List<Flight> FetchAllFlight() {
		List<Flight> flights=super.findAll("Flight");
		return flights;
	}

	@Transactional
	public void updateFlight(Flight fobj) {
		super.merge(fobj);		
	}

	@Transactional
	public void deleteFlight(int fid) {
	super.remove(Flight.class, fid);
		
	}

	
	
}

